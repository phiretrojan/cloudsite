<div class="preloader-area">
    <div class='coin'>
        <div class='front jump'>
            <div class='star'></div>
            <span class='currency'><i class="las la-coins"></i></span>
            <div class='shapes'>
                <div class='shape_l'></div>
                <div class='shape_r'></div>
                <span class='top'>{{ $general->preloader_title }}</span>
                <span class='bottom'>{{ $general->preloader_title }}</span>
            </div>
        </div>
        <div class='shadow'></div>
    </div>
</div>
